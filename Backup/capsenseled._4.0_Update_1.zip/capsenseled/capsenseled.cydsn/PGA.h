/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/


#ifndef PGA_H
#define PGA_H
    
void PGA_set_gain(float gain);
void PGA_program_resistor(float resistance);
#endif

/* [] END OF FILE */
